<?php

$xml=simplexml_load_file($userfile);

?>