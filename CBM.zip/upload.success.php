<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="target-densitydpi=device-dpi, width=device-width, initial-scale=1.0, maximum-scale=1">

    <link href="/css/modern.css" rel="stylesheet">
    <link href="/css/theme-dark.css" rel="stylesheet">
    <link href="/css/modern-responsive.css" rel="stylesheet">

    <script src="/js/assets/jquery-1.8.2.min.js"></script>
    

<title>CBM Intranet Edit Page</title>
    <style>
	#Upload {
	width: 25em;
	margin: 1em auto;
	padding:0 2em 2em 2em ;
	border:1px solid #bbb;
	color: #FFF;
	background:#ffd;
	font: 0.9em verdana, sans-serif;
}
			
#Upload h1{
	font: 1.4em bold verdana, sans-serif;
	margin: 0;
	padding:1em 0;
	text-align:center;
}
#Upload label{
	float: left;
	width: 7em;
}
		
#Upload p {
	 clear: both;
}		

.red{
	color:red;
}
	</style>
</head>
<body class="metrouicss" style="padding:20px;"> 
     
        <div id="Upload"> 
            <h1>File upload</h1> 
            <p>Congratulations! Your file upload was successful</p> 
        </div> 
     
    </body> 

</html> 