<?php
$xmlM=simplexml_load_file("messages.xml");

?>