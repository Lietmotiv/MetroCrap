<?php
include_once('check_mypage.php');
?>
<!DOCTYPE html>
<?php
include "xml.php";
include "messagesXML.php";
?>
<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="target-densitydpi=device-dpi, width=device-width, initial-scale=1.0, maximum-scale=1">

    <link href="/css/modern.css" rel="stylesheet">
    <link href="/css/theme-dark.css" rel="stylesheet">
    <link href="/css/modern-responsive.css" rel="stylesheet">

    <script src="/js/assets/jquery-1.8.2.min.js"></script>
    <script src="/js/assets/google-analytics.js"></script>
    <script src="/js/assets/jquery.mousewheel.min.js"></script>
    <script src="/js/assets/github.info.js"></script>
    <script src="/js/modern/tile-slider.js"></script>
    <script src="/js/modern/start-menu.js"></script>
    <script src="/js/modern/tile-drag.js"></script>

    <title>CBM Intranet</title>
	<script type="text/javascript">
            
            $(document).ready(function(){
            
                $("button").click(function(){
                    save();
                });
    
                function save() {
                    var elem = document.getElementById("settings");				
                    var html = document.getElementsByTagName('html')[0].innerHTML;
                    //$("body").html();
                    $("#settings").val(html).parents("form").submit();
                }
                    
                //var win = window.open(); win.document.write('<html><head><title>Generated HTML of  ' + location.href + '</title></head><pre>' + document.documentElement.innerHTML.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</pre></html>'); win.document.close(); void 0;
            });
	</script>
    
</head>
<body class="metrouicss">
<div class="page secondary fixed-header">
    <div class="page-header ">
        <div class="page-header-content">
            <div class="user-login">
                <a href="edit.php">
                    <div class="name">
                        <span class="first-name"><?php echo $xml-> first; ?></span>
                        <span class="last-name"><?php echo $xml-> last; ?></span>
                       
                    </div>
                    <div class="avatar">
                        <img src="/profiles/<?php echo $xml-> image; ?>"/>
                    </div>
                </a>
            </div>

            <h1 class="fg-color-white"><img src="/images/cbmLogo1.png" width="200" height="75"></h1>
        </div>
    </div>


<?php 
include_once($mypage);
?>
</div>

 <form action="settings.php" method="post">
						<!-- <input type='hidden' id='settings'> -->
						<input type='hidden' name='usr' value='<?php $_SESSION['user']?>'>
						<textarea id="settings" name="content" style="width:0; height:0;"></textarea>
						<button onclick="save()" style="display:none;">Save settings</button>
</form>	
</body>
</html>